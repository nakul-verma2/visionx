import argparse
from ultralytics import YOLO
import os
import sys
# Default values from your notebook
DEFAULTS = {
    'epochs': 10,
    'mosaic': 0.1,
    'optimizer': 'SGD',
    'momentum': 0.937,
    'lr0': 0.005,
    'lrf': 0.01,
    'single_cls': False,
    'hsv_h': 0.015,
    'hsv_s': 0.7,
    'hsv_v': 0.4,
    'degrees': 10.0,
    'translate': 0.1,
    'scale': 0.5,
    'shear': 2.0,
    'flipud': 0.5,
    'fliplr': 0.5,
    'mixup': 0.2,
    'device': 0,
    'batch': 8,
    'imgsz': 640,
    'pretrained': True,
    'resume': False,
    'data_path': 'yolo_params.yaml',
    'weights_path': 'new1.pt'
}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Train YOLOv8 with advanced config")

    # Basic hyperparameters
    parser.add_argument('--epochs', type=int, default=DEFAULTS['epochs'])
    parser.add_argument('--mosaic', type=float, default=DEFAULTS['mosaic'])
    parser.add_argument('--optimizer', type=str, default=DEFAULTS['optimizer'])
    parser.add_argument('--momentum', type=float, default=DEFAULTS['momentum'])
    parser.add_argument('--lr0', type=float, default=DEFAULTS['lr0'])
    parser.add_argument('--lrf', type=float, default=DEFAULTS['lrf'])
    parser.add_argument('--single_cls', type=bool, default=DEFAULTS['single_cls'])

    # Augmentations
    parser.add_argument('--hsv_h', type=float, default=DEFAULTS['hsv_h'])
    parser.add_argument('--hsv_s', type=float, default=DEFAULTS['hsv_s'])
    parser.add_argument('--hsv_v', type=float, default=DEFAULTS['hsv_v'])
    parser.add_argument('--degrees', type=float, default=DEFAULTS['degrees'])
    parser.add_argument('--translate', type=float, default=DEFAULTS['translate'])
    parser.add_argument('--scale', type=float, default=DEFAULTS['scale'])
    parser.add_argument('--shear', type=float, default=DEFAULTS['shear'])
    parser.add_argument('--flipud', type=float, default=DEFAULTS['flipud'])
    parser.add_argument('--fliplr', type=float, default=DEFAULTS['fliplr'])
    parser.add_argument('--mixup', type=float, default=DEFAULTS['mixup'])

    # Misc
    parser.add_argument('--device', type=str, default=DEFAULTS['device'])
    parser.add_argument('--batch', type=int, default=DEFAULTS['batch'])
    parser.add_argument('--imgsz', type=int, default=DEFAULTS['imgsz'])
    parser.add_argument('--resume', type=bool, default=DEFAULTS['resume'])
    parser.add_argument('--pretrained', type=bool, default=DEFAULTS['pretrained'])

    # Paths
    parser.add_argument('--data', type=str, default=DEFAULTS['data_path'], help="Path to data.yaml")
    parser.add_argument('--weights', type=str, default=DEFAULTS['weights_path'], help="Path to pretrained weights")

    args = parser.parse_args()

    this_dir = os.path.dirname(__file__)
    os.chdir(this_dir)

    # Load and train the model
    model = YOLO(os.path.join(this_dir, "new1.pt"))  # Load a pretrained model
    results = model.train(
        data=os.path.join(this_dir, "yolo_params.yaml"),
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        device=args.device,
        single_cls=args.single_cls,
        mosaic=args.mosaic,
        optimizer=args.optimizer,
        lr0=args.lr0,
        lrf=args.lrf,
        momentum=args.momentum,
        pretrained=args.pretrained,
        resume=args.resume,
        hsv_h=args.hsv_h,
        hsv_s=args.hsv_s,
        hsv_v=args.hsv_v,
        degrees=args.degrees,
        translate=args.translate,
        scale=args.scale,
        shear=args.shear,
        flipud=args.flipud,
        fliplr=args.fliplr,
        mixup=args.mixup
    )

'''
Mixup boost val pred but reduces test pred
Mosaic shouldn't be 1.0  
'''


'''
                   from  n    params  module                                       arguments
  0                  -1  1       464  ultralytics.nn.modules.conv.Conv             [3, 16, 3, 2]
  1                  -1  1      4672  ultralytics.nn.modules.conv.Conv             [16, 32, 3, 2]
  2                  -1  1      7360  ultralytics.nn.modules.block.C2f             [32, 32, 1, True]
  3                  -1  1     18560  ultralytics.nn.modules.conv.Conv             [32, 64, 3, 2]
  4                  -1  2     49664  ultralytics.nn.modules.block.C2f             [64, 64, 2, True]
  5                  -1  1     73984  ultralytics.nn.modules.conv.Conv             [64, 128, 3, 2]
  6                  -1  2    197632  ultralytics.nn.modules.block.C2f             [128, 128, 2, True]
  7                  -1  1    295424  ultralytics.nn.modules.conv.Conv             [128, 256, 3, 2]
  8                  -1  1    460288  ultralytics.nn.modules.block.C2f             [256, 256, 1, True]
  9                  -1  1    164608  ultralytics.nn.modules.block.SPPF            [256, 256, 5]
 10                  -1  1         0  torch.nn.modules.upsampling.Upsample         [None, 2, 'nearest']
 11             [-1, 6]  1         0  ultralytics.nn.modules.conv.Concat           [1]
 12                  -1  1    148224  ultralytics.nn.modules.block.C2f             [384, 128, 1]
 13                  -1  1         0  torch.nn.modules.upsampling.Upsample         [None, 2, 'nearest']
 14             [-1, 4]  1         0  ultralytics.nn.modules.conv.Concat           [1]
 15                  -1  1     37248  ultralytics.nn.modules.block.C2f             [192, 64, 1]
 16                  -1  1     36992  ultralytics.nn.modules.conv.Conv             [64, 64, 3, 2]
 17            [-1, 12]  1         0  ultralytics.nn.modules.conv.Concat           [1]
 18                  -1  1    123648  ultralytics.nn.modules.block.C2f             [192, 128, 1]
 19                  -1  1    147712  ultralytics.nn.modules.conv.Conv             [128, 128, 3, 2]
 20             [-1, 9]  1         0  ultralytics.nn.modules.conv.Concat           [1]
 21                  -1  1    493056  ultralytics.nn.modules.block.C2f             [384, 256, 1]
 22        [15, 18, 21]  1    751507  ultralytics.nn.modules.head.Detect           [1, [64, 128, 256]]
Model summary: 225 layers, 3,011,043 parameters, 3,011,027 gradients, 8.2 GFLOPs
'''