import argparse
from ultralytics import YOLO
import os
import sys

# Default values from Notebook
DEFAULTS = {
    'epochs': 10,
    'mosaic': 0.1,
    'optimizer': 'SGD',
    'momentum': 0.937,
    'lr0': 0.005,
    'lrf': 0.01,
    'single_cls': False,
    'hsv_h': 0.015,
    'hsv_s': 0.7,
    'hsv_v': 0.4,
    'degrees': 10.0,
    'translate': 0.1,
    'scale': 0.5,
    'shear': 2.0,
    'flipud': 0.5,
    'fliplr': 0.5,
    'mixup': 0.2,
    'device': 0,
    'batch': 16,
    'imgsz': 640,
    'pretrained': True,
    'resume': False,
    'data_path': 'yolo_params.yaml',  # .yaml in same folder as train.py
    'weights_path': 'runs/train/weights/last.pt'  # .pt in Model\runs\train\weights
}

if __name__ == '__main__':
    parser = argparse.ArgumentParser(description="Train YOLOv8 with advanced config")

    # Basic hyperparameters
    parser.add_argument('--epochs', type=int, default=DEFAULTS['epochs'])
    parser.add_argument('--mosaic', type=float, default=DEFAULTS['mosaic'])
    parser.add_argument('--optimizer', type=str, default=DEFAULTS['optimizer'])
    parser.add_argument('--momentum', type=float, default=DEFAULTS['momentum'])
    parser.add_argument('--lr0', type=float, default=DEFAULTS['lr0'])
    parser.add_argument('--lrf', type=float, default=DEFAULTS['lrf'])
    parser.add_argument('--single_cls', type=bool, default=DEFAULTS['single_cls'])

    # Augmentations
    parser.add_argument('--hsv_h', type=float, default=DEFAULTS['hsv_h'])
    parser.add_argument('--hsv_s', type=float, default=DEFAULTS['hsv_s'])
    parser.add_argument('--hsv_v', type=float, default=DEFAULTS['hsv_v'])
    parser.add_argument('--degrees', type=float, default=DEFAULTS['degrees'])
    parser.add_argument('--translate', type=float, default=DEFAULTS['translate'])
    parser.add_argument('--scale', type=float, default=DEFAULTS['scale'])
    parser.add_argument('--shear', type=float, default=DEFAULTS['shear'])
    parser.add_argument('--flipud', type=float, default=DEFAULTS['flipud'])
    parser.add_argument('--fliplr', type=float, default=DEFAULTS['fliplr'])
    parser.add_argument('--mixup', type=float, default=DEFAULTS['mixup'])

    # Misc
    parser.add_argument('--device', type=str, default=DEFAULTS['device'])
    parser.add_argument('--batch', type=int, default=DEFAULTS['batch'])
    parser.add_argument('--imgsz', type=int, default=DEFAULTS['imgsz'])
    parser.add_argument('--resume', type=bool, default=DEFAULTS['resume'])
    parser.add_argument('--pretrained', type=bool, default=DEFAULTS['pretrained'])

    # Paths
    parser.add_argument('--data', type=str, default=DEFAULTS['data_path'], help="Path to data.yaml")
    parser.add_argument('--weights', type=str, default=DEFAULTS['weights_path'], help="Path to pretrained weights")

    args = parser.parse_args()

    this_dir = os.path.dirname(__file__)
    os.chdir(this_dir)

    # Load and train the model
    model = YOLO(os.path.join(this_dir, args.weights))  # Load pretrained model from runs/train/weights
    results = model.train(
        data=os.path.join(this_dir, args.data),  # .yaml in same folder
        epochs=args.epochs,
        imgsz=args.imgsz,
        batch=args.batch,
        device=args.device,
        single_cls=args.single_cls,
        mosaic=args.mosaic,
        optimizer=args.optimizer,
        lr0=args.lr0,
        lrf=args.lrf,
        momentum=args.momentum,
        pretrained=args.pretrained,
        resume=args.resume,
        hsv_h=args.hsv_h,
        hsv_s=args.hsv_s,
        hsv_v=args.hsv_v,
        degrees=args.degrees,
        translate=args.translate,
        scale=args.scale,
        shear=args.shear,
        flipud=args.flipud,
        fliplr=args.fliplr,
        mixup=args.mixup
    )